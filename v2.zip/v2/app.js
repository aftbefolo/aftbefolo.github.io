// === BASEMAPS ===
const osmLayer = new ol.layer.Tile({
  title: 'OpenStreetMap',
  type: 'base',
  visible: true,
  source: new ol.source.OSM()
});

const satelliteLayer = new ol.layer.Tile({
  title: 'Satellite',
  type: 'base',
  visible: false,
  source: new ol.source.XYZ({
      url: 'https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
  })
});

const terrainLayer = new ol.layer.Tile({
  title: 'Terrain',
  type: 'base',
  visible: false,
  source: new ol.source.XYZ({
      url: 'https://stamen-tiles.a.ssl.fastly.net/terrain/{z}/{x}/{y}.jpg',
      attributions: 'Map tiles by Stamen Design, CC BY 3.0 — Map data © OpenStreetMap'
  })
});

const cartoLayer = new ol.layer.Tile({
  title: 'CartoDB Positron',
  type: 'base',
  visible: false,
  source: new ol.source.XYZ({
      url: 'https://{a-c}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png',
      attributions: '© OpenStreetMap, © CARTO'
  })
});

// === MAP ===
const map = new ol.Map({
  target: 'map',
  layers: [osmLayer, satelliteLayer, terrainLayer, cartoLayer],
  view: new ol.View({ center: [0, 0], zoom: 2 })
});

// LayerSwitcher
const layerSwitcher = new ol.control.LayerSwitcher({ reverse: true });
map.addControl(layerSwitcher);

// Popup overlay
const overlay = new ol.Overlay({
  element: document.getElementById('popup'),
  autoPan: true,
  autoPanAnimation: { duration: 250 }
});
map.addOverlay(overlay);

document.getElementById('popup-closer').onclick = function() {
  overlay.setPosition(undefined);
  this.blur();
  return false;
};

// === UI ELEMENTS ===
const shpInput = document.getElementById('shp-input');
const layersList = document.getElementById('layers-list');
const styleLayerSel = document.getElementById('style-layer');
const attrLayerSel = document.getElementById('attr-layer');
const fillColorInput = document.getElementById('fill-color');
const strokeColorInput = document.getElementById('stroke-color');
const strokeWidthInput = document.getElementById('stroke-width');
const fillOpacityInput = document.getElementById('fill-opacity');
const pointSymbolSel = document.getElementById('point-symbol');
const legendDiv = document.getElementById('legend');
const attributeSelect = document.getElementById('attribute-select');
const attributeSLabel = document.getElementById('attribute-label');
const attributeFilter = document.getElementById('attribute-filter');
const clearFilterBtn = document.getElementById('clear-filter');
const attributesHeader = document.getElementById('attributes-header');
const attributesBody = document.getElementById('attributes-body');
const fontFamilySel = document.getElementById('font-family');
const fontSizeInput = document.getElementById('font-size');
const textColorInput = document.getElementById('textColor');
const textStrokeInput = document.getElementById('textStrokeColor');

// === DATA ===
let layers = [];
let highlighted = [];

// === DEFAULT STYLE ===
function defaultStyle(feature) {
  return new ol.style.Style({
      fill: new ol.style.Fill({ color: 'rgba(255,0,0,0.6)' }),
      stroke: new ol.style.Stroke({ color: '#000', width: 2 }),
      image: new ol.style.Circle({ 
          radius: 5, 
          fill: new ol.style.Fill({ color: '#ff0000' }), 
          stroke: new ol.style.Stroke({ width: 2, color: '#000' }) 
      })
  });
}

const highlightStyle = new ol.style.Style({
  fill: new ol.style.Fill({ color: 'rgba(255,255,0,0.7)' }),
  stroke: new ol.style.Stroke({ color: '#ff0', width: 3 }),
  image: new ol.style.Circle({
      radius: 7,
      fill: new ol.style.Fill({ color: '#ff0' }),
      stroke: new ol.style.Stroke({ width: 3, color: '#000' })
  })
});

// === HEX TO RGBA CONVERSION ===
function hexToRgba(hex, opacity) {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r}, ${g}, ${b}, ${opacity})`;
}

// === IMPORT SHAPEFILE ===
shpInput.addEventListener('change', async e => {
  const buffer = await e.target.files[0].arrayBuffer();
  const geojson = await shp(buffer);

  const source = new ol.source.Vector({ 
      features: new ol.format.GeoJSON().readFeatures(geojson, { 
          featureProjection: 'EPSG:3857' 
      }) 
  });
  
  const layer = new ol.layer.Vector({ 
      source, 
      style: defaultStyle, 
      title: e.target.files[0].name 
  });
  
  map.addLayer(layer);

  let layerName = e.target.files[0].name;
  let i = 1;
  while (layers.find(l => l.name === layerName)) {
      layerName = `${e.target.files[0].name}_${i++}`;
  }

  layers.push({
      layer: layer,
      geojson: geojson,
      name: layerName,
      style: {
          fillColor: '#ff0000',
          strokeColor: '#000000',
          strokeWidth: 2,
          fillOpacity: 0.6,
          pointSymbol: 'circle',
          labelAttribute: null,
          fontFamily: 'Arial',
          fontSize: 12,
          textColor: '#000000',
          textStrokeColor: '#ffffff'
      }
  });
  
  updateUI();
});

// === UPDATE UI ===
function updateUI() {
  layersList.innerHTML = styleLayerSel.innerHTML = attrLayerSel.innerHTML = legendDiv.innerHTML = '';

  layers.forEach((item, i) => {
      const li = document.createElement('li');
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = true;
      cb.onchange = () => item.layer.setVisible(cb.checked);
      li.append(cb, document.createTextNode(item.layer.get('title')));
      layersList.appendChild(li);

      const optStyle = document.createElement('option');
      optStyle.value = i;
      optStyle.text = item.layer.get('title');
      styleLayerSel.appendChild(optStyle);

      const optAttr = document.createElement('option');
      optAttr.value = i;
      optAttr.text = item.layer.get('title');
      attrLayerSel.appendChild(optAttr);

      legendDiv.appendChild(buildLegendItem(item));
  });

  if (layers.length) {
      setupAttributesTable(layers[attrLayerSel.value].geojson);
      setLabelOptions(layers[styleLayerSel.value].geojson);
      updateStylePanel();
      applyStyle();
  }
}

// === LEGEND MANAGEMENT ===
function buildLegendItem(item) {
  const div = document.createElement('div');
  div.className = 'legend-item';

  const geoType = item.geojson.features[0].geometry.type;
  const style = item.style;

  let symbol;
  if (geoType === 'Point' || geoType === 'MultiPoint') {
      symbol = createPointSymbol(style);
  } else if (geoType === 'LineString' || geoType === 'MultiLineString') {
      symbol = createLineSymbol(style);
  } else {
      symbol = createPolygonSymbol(style);
  }

  div.appendChild(symbol);
  div.appendChild(document.createTextNode(item.layer.get('title')));
  return div;
}

function createPointSymbol(style) {
  const span = document.createElement('span');
  span.className = 'symbol';
  span.style.backgroundColor = style.fillColor;
  span.style.border = `${style.strokeWidth}px solid ${style.strokeColor}`;
  span.style.borderRadius = style.pointSymbol === 'circle' ? '50%' : '0';
  span.style.width = span.style.height = '18px';
  return span;
}

function createLineSymbol(style) {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 18;
  const ctx = canvas.getContext('2d');
  ctx.strokeStyle = style.strokeColor;
  ctx.lineWidth = style.strokeWidth;
  ctx.beginPath();
  ctx.moveTo(2, 16);
  ctx.lineTo(16, 2);
  ctx.stroke();
  return canvas;
}

function createPolygonSymbol(style) {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 18;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = hexToRgba(style.fillColor, style.fillOpacity);
  ctx.strokeStyle = style.strokeColor;
  ctx.lineWidth = style.strokeWidth;
  ctx.fillRect(2, 2, 14, 14);
  ctx.strokeRect(2, 2, 14, 14);
  return canvas;
}

function updateLegend() {
  legendDiv.innerHTML = '';
  layers.forEach(item => {
      legendDiv.appendChild(buildLegendItem(item));
  });
}

// === ATTRIBUTE TABLE ===
function setupAttributesTable(geojson) {
  attributesHeader.innerHTML = attributesBody.innerHTML = attributeSelect.innerHTML = '';

  const keys = Object.keys(geojson.features[0].properties);
  keys.forEach(k => {
      const th = document.createElement('th');
      th.textContent = k;
      attributesHeader.appendChild(th);
      
      const opt = document.createElement('option');
      opt.value = k;
      opt.text = k;
      attributeSelect.appendChild(opt);
  });

  geojson.features.forEach((f, idx) => {
      const tr = document.createElement('tr');
      tr.dataset.index = idx;
      keys.forEach(k => {
          const td = document.createElement('td');
          td.textContent = f.properties[k];
          tr.appendChild(td);
      });
      
      tr.onclick = () => {
          zoomToFeature(idx);
          showPopup(idx);
      };
      attributesBody.appendChild(tr);
  });
}

// === FILTER ===
attributeFilter.addEventListener('input', applyFilter);

function applyFilter() {
  clearHighlight();
  const field = attributeSelect.value;
  const term = attributeFilter.value.toLowerCase();
  
  if (!term) {
      Array.from(attributesBody.rows).forEach(r => r.style.display = '');
      return;
  }

  Array.from(attributesBody.rows).forEach(row => {
      const idx = +row.dataset.index;
      const val = layers[attrLayerSel.value].geojson.features[idx].properties[field] + '';
      const match = val.toLowerCase().includes(term);
      row.style.display = match ? '' : 'none';
      if (match) highlightFeature(idx);
  });
}

// === HIGHLIGHT ===
function highlightFeature(idx) {
  const feat = layers[attrLayerSel.value].layer.getSource().getFeatures()[idx];
  feat.setStyle(highlightStyle);
  highlighted.push(feat);
}

function clearHighlight() {
  highlighted.forEach(f => {
      // Trouver la couche parente du feature
      const parentLayer = layers.find(l => 
          l.layer.getSource().getFeatures().includes(f)
      );
      
      // Réappliquer le style de la couche
      if (parentLayer) {
          const style = generateFeatureStyle(parentLayer.style, f);
          f.setStyle(style);
      }
  });
  highlighted = [];
}

// Effacer filtre
clearFilterBtn.addEventListener('click', () => {
  attributeFilter.value = '';
  Array.from(attributesBody.rows).forEach(r => r.style.display = '');
  clearHighlight();
});

// Helper pour générer le style d'un feature
function generateFeatureStyle(layerStyle, feature) {
  const fill = new ol.style.Fill({ 
      color: hexToRgba(layerStyle.fillColor, layerStyle.fillOpacity) 
  });
  
  const stroke = new ol.style.Stroke({ 
      color: layerStyle.strokeColor, 
      width: layerStyle.strokeWidth 
  });

  let image;
  switch(layerStyle.pointSymbol) {
      case 'square':
          image = new ol.style.RegularShape({
              points: 4, radius: 6, angle: Math.PI/4, fill, stroke
          });
          break;
      case 'triangle':
          image = new ol.style.RegularShape({
              points: 3, radius: 7, angle: 0, fill, stroke
          });
          break;
      case 'star':
          image = new ol.style.RegularShape({
              points: 5, radius: 8, radius2: 4, angle: 0, fill, stroke
          });
          break;
      case 'cross':
          image = new ol.style.RegularShape({
              points: 4, radius: 6, radius2: 0, angle: 0, stroke
          });
          break;
      default:
          image = new ol.style.Circle({ radius: 6, fill, stroke });
  }

  const textVal = layerStyle.labelAttribute ? 
  feature.get(layerStyle.labelAttribute)?.toString() || '' : '';

  const text = new ol.style.Text({
    text: textVal,
    font: `${layerStyle.fontSize}px ${layerStyle.fontFamily}`,
    fill: new ol.style.Fill({ color: layerStyle.textColor }),
    stroke: new ol.style.Stroke({ 
        color: layerStyle.textStrokeColor, 
        width: 2 
    }),
    offsetY: -15
  });

  return new ol.style.Style({ fill, stroke, image, text });
}

// === ZOOM & POPUP ===
function zoomToFeature(idx) {
  const feature = layers[attrLayerSel.value].layer.getSource().getFeatures()[idx];
  map.getView().fit(feature.getGeometry(), { 
      duration: 500, 
      padding: [100, 100, 100, 100] 
  });
}

function showPopup(idx) {
  const feature = layers[attrLayerSel.value].layer.getSource().getFeatures()[idx];
  const coord = feature.getGeometry().getClosestPoint(map.getView().getCenter());
  const props = { ...feature.getProperties() };
  delete props.geometry;
  
  let html = '<table>';
  Object.keys(props).forEach(k => {
      html += `<tr><th>${k}</th><td>${props[k]}</td></tr>`;
  });
  html += '</table>';
  
  document.getElementById('popup-content').innerHTML = html;
  overlay.setPosition(coord);
}

map.on('singleclick', evt => {
  clearHighlight();
  map.forEachFeatureAtPixel(evt.pixel, (feature) => {
      const props = { ...feature.getProperties() };
      delete props.geometry;
      
      let info = '<table>';
      Object.keys(props).forEach(k => {
          info += `<tr><th>${k}</th><td>${props[k]}</td></tr>`;
      });
      info += '</table>';
      
      document.getElementById('popup-content').innerHTML = info;
      overlay.setPosition(evt.coordinate);
  });
});

// === SELECT OPTIONS ===
attrLayerSel.addEventListener('change', () => {
  setupAttributesTable(layers[attrLayerSel.value].geojson);
});

styleLayerSel.addEventListener('change', () => {
  updateStylePanel();
  setLabelOptions(layers[styleLayerSel.value].geojson);
});

function setLabelOptions(geojson) {
  attributeSLabel.innerHTML = '';
  attributeSLabel.add(new Option('Pas d\'étiquette', 'null'));
  Object.keys(geojson.features[0].properties).forEach(k => {
      attributeSLabel.add(new Option(k, k));
  });
}

// === STYLE MANAGEMENT ===
[fillColorInput, strokeColorInput, strokeWidthInput, fillOpacityInput, 
pointSymbolSel, attributeSLabel, fontFamilySel, fontSizeInput, 
textColorInput, textStrokeInput].forEach(el => {
  el.onchange = () => {
      updateLayerStyle();
      applyStyle();
  };
});

function updateLayerStyle() {
  if (!layers.length) return;
  const idx = +styleLayerSel.value;
  const currentStyle = layers[idx].style;

  currentStyle.fillColor = fillColorInput.value;
  currentStyle.strokeColor = strokeColorInput.value;
  currentStyle.strokeWidth = +strokeWidthInput.value;
  currentStyle.fillOpacity = +fillOpacityInput.value;
  currentStyle.pointSymbol = pointSymbolSel.value;
  currentStyle.labelAttribute = attributeSLabel.value;
  currentStyle.fontFamily = fontFamilySel.value;
  currentStyle.fontSize = +fontSizeInput.value;
  currentStyle.textColor = textColorInput.value;
  currentStyle.textStrokeColor = textStrokeInput.value;
  currentStyle.labelAttribute = attributeSLabel.value === 'null' ? null : attributeSLabel.value;
}

function updateStylePanel() {
  if (!layers.length) return;
  const idx = +styleLayerSel.value;
  const currentStyle = layers[idx].style;

  fillColorInput.value = currentStyle.fillColor;
  strokeColorInput.value = currentStyle.strokeColor;
  strokeWidthInput.value = currentStyle.strokeWidth;
  fillOpacityInput.value = currentStyle.fillOpacity;
  pointSymbolSel.value = currentStyle.pointSymbol;
  attributeSLabel.value = currentStyle.labelAttribute;
  fontFamilySel.value = currentStyle.fontFamily;
  fontSizeInput.value = currentStyle.fontSize;
  textColorInput.value = currentStyle.textColor;
  textStrokeInput.value = currentStyle.textStrokeColor;
  attributeSLabel.value = currentStyle.labelAttribute || 'null';
}

function applyStyle() {
  if (!layers.length) return;
  
  const idx = +styleLayerSel.value;
  const { layer, style } = layers[idx];
  const labelField = style.labelAttribute === 'null' ? null : style.labelAttribute;

  const fillStyle = new ol.style.Fill({ 
      color: hexToRgba(style.fillColor, style.fillOpacity) 
  });
  
  const strokeStyle = new ol.style.Stroke({ 
      color: style.strokeColor, 
      width: style.strokeWidth 
  });

  layer.setStyle(feature => {
      const textStyle = new ol.style.Text({
          text: labelField ? String(feature.get(labelField) ?? '') : '',
          font: `${style.fontSize}px ${style.fontFamily}`,
          fill: new ol.style.Fill({ color: style.textColor }),
          stroke: new ol.style.Stroke({ 
              color: style.textStrokeColor, 
              width: 2 
          }),
          offsetY: -15
      });

      let imageStyle;
      switch(style.pointSymbol) {
          case 'square':
              imageStyle = new ol.style.RegularShape({
                  points: 4,
                  radius: 6,
                  angle: Math.PI/4,
                  fill: fillStyle,
                  stroke: strokeStyle
              });
              break;
          case 'triangle':
              imageStyle = new ol.style.RegularShape({
                  points: 3,
                  radius: 7,
                  angle: 0,
                  fill: fillStyle,
                  stroke: strokeStyle
              });
              break;
          case 'star':
              imageStyle = new ol.style.RegularShape({
                  points: 5,
                  radius: 8,
                  radius2: 4,
                  angle: 0,
                  fill: fillStyle,
                  stroke: strokeStyle
              });
              break;
          case 'cross':
              imageStyle = new ol.style.RegularShape({
                  points: 4,
                  radius: 6,
                  radius2: 0,
                  angle: 0,
                  fill: strokeStyle,
                  stroke: strokeStyle
              });
              break;
          default:
              imageStyle = new ol.style.Circle({
                  radius: 6,
                  fill: fillStyle,
                  stroke: strokeStyle
              });
      }

      return new ol.style.Style({
          fill: fillStyle,
          stroke: strokeStyle,
          image: imageStyle,
          text: textStyle
      });
  });

  updateLegend();
}

// Initialisation
updateUI();