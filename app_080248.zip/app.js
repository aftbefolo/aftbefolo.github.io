// Carte OpenLayers
const map = new ol.Map({
  target: 'map',
  layers: [new ol.layer.Tile({ source: new ol.source.OSM(), title: 'OSM de base', type: 'base' })],
  view: new ol.View({ center: [0, 0], zoom: 2 })
});

// LayerSwitcher
const layerSwitcher = new ol.control.LayerSwitcher({ reverse: true });
map.addControl(layerSwitcher);

// Popup overlay
const popupContainer = document.getElementById('popup');
const popupContent = document.getElementById('popup-content');
const popupCloser = document.getElementById('popup-closer');
const overlay = new ol.Overlay({
  element: popupContainer,
  autoPan: true,
  autoPanAnimation: { duration: 250 }
});
map.addOverlay(overlay);
popupCloser.onclick = function() {
  overlay.setPosition(undefined);
  popupCloser.blur();
  return false;
};

// For layers attributs
const layerAttribut = ''

// UI refs
const shpInput = document.getElementById('shp-input');
const layersList = document.getElementById('layers-list');
const styleLayerSel = document.getElementById('style-layer');
const attrLayerSel = document.getElementById('attr-layer');
const fillColorInput = document.getElementById('fill-color');
const strokeColorInput = document.getElementById('stroke-color');
const strokeWidthInput = document.getElementById('stroke-width');
const fillOpacityInput = document.getElementById('fill-opacity');
const pointSymbolSel = document.getElementById('point-symbol');
const legendDiv = document.getElementById('legend');
const attributeSelect = document.getElementById('attribute-select');
const attributeSLabel = document.getElementById('attribute-label');
const attributeFilter = document.getElementById('attribute-filter');
const clearFilterBtn = document.getElementById('clear-filter');
const attributesHeader = document.getElementById('attributes-header');
const attributesBody = document.getElementById('attributes-body');

// Data
let layers = [];
let highlighted = [];

// Styles
function defaultStyle(feature) {
  return new ol.style.Style({
    fill: new ol.style.Fill({ color: 'rgba(255,0,0,0.6)' }),
    stroke: new ol.style.Stroke({ color: '#000', width: 2 }),
    image: new ol.style.Circle({ radius: 5, fill: new ol.style.Fill({ color: '#ff0000' }), stroke: new ol.style.Stroke({ width: 2, color: '#000' }) })
  });
}
const highlightStyle = new ol.style.Style({
  fill: new ol.style.Fill({ color: 'rgba(255,255,0,0.7)' }),
  stroke: new ol.style.Stroke({ color: '#ff0', width: 3 }),
  image: new ol.style.Circle({ radius: 7, fill: new ol.style.Fill({ color: '#ff0' }), stroke: new ol.style.Stroke({ width: 3, color: '#000' }) })
});

// Import shapefile
shpInput.addEventListener('change', async e => {
  const buffer = await e.target.files[0].arrayBuffer();
  const geojson = await shp(buffer);
  const source = new ol.source.Vector({ features: new ol.format.GeoJSON().readFeatures(geojson, { featureProjection: 'EPSG:3857' }) });
  const layer = new ol.layer.Vector({ source, style: defaultStyle, title: e.target.files[0].name });
  map.addLayer(layer);

  // Layer name test
  let layerName = e.target.files[0].name;
  let i = 1;
  while (layers.find(layer => layer.name === layerName)) {
    layerName = e.target.files[0].name + i;
    i++;
    }
  layers.push({ layer, geojson });
  updateUI();
});

// Met à jour l'UI
function updateUI() {
  layersList.innerHTML = '';
  styleLayerSel.innerHTML = '';
  attrLayerSel.innerHTML = '';
  legendDiv.innerHTML = '';

  layers.forEach((item, i) => {
    // Visibilité
    const li = document.createElement('li');
    const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = true;
    cb.onchange = () => item.layer.setVisible(cb.checked);
    li.append(cb, document.createTextNode(item.layer.get('title')));
    layersList.appendChild(li);

    // Style panel
    const opt = document.createElement('option'); opt.value = i; opt.text = item.layer.get('title');
    const opt1 = document.createElement('option'); opt1.value = i; opt1.text = item.layer.get('title');
    styleLayerSel.appendChild(opt);
    attrLayerSel.appendChild(opt1);

    // Légende
    const legendItem = document.createElement('div'); legendItem.textContent = item.layer.get('title');
    legendDiv.appendChild(legendItem);
  });

  if (layers.length) {
    setupAttributesTable(layers[attrLayerSel.value].geojson);
    setOptionForLabel(layers[styleLayerSel.value].geojson);
    applyStyle();
  };
}

// Table attributs
function setupAttributesTable(geojson) {
  attributesHeader.innerHTML = '';
  attributesBody.innerHTML = '';
  attributeSelect.innerHTML = '';

  const keys = Object.keys(geojson.features[0].properties);
  keys.forEach(k => {
    const th = document.createElement('th'); th.textContent = k;
    attributesHeader.appendChild(th);
    const opt = document.createElement('option'); opt.value = k; opt.text = k;
    attributeSelect.appendChild(opt);
  });

  geojson.features.forEach((f, idx) => {
    const tr = document.createElement('tr'); tr.dataset.index = idx;
    keys.forEach(k => {
      const td = document.createElement('td'); td.textContent = f.properties[k]; tr.appendChild(td);
    });
    // clic sur table → zoom + popup
    tr.onclick = () => {
      zoomToFeature(idx);
      showPopup(idx);
    };
    attributesBody.appendChild(tr);
  });
}

// Filtrage
attributeFilter.addEventListener('input', applyFilter);
function applyFilter() {
  clearHighlight();
  const field = attributeSelect.value;
  const term = attributeFilter.value.toLowerCase();
  
  // verifier si le term n'est pas vide 
  if (term) {
  Array.from(attributesBody.rows).forEach(row => {
    const idx = +row.dataset.index;
    const val = layers[attrLayerSel.value].geojson.features[idx].properties[field] + '';
    const match = val.toLowerCase().includes(term);
    row.style.display = match ? '' : 'none';
    if (match) highlightFeature(idx);
  })};
}

// Highlight
function highlightFeature(idx) {
  const feat = layers[attrLayerSel.value].layer.getSource().getFeatures()[idx];
  feat.setStyle(highlightStyle);
  highlighted.push(feat);
}
function clearHighlight() {
  highlighted.forEach(f => f.setStyle(defaultStyle(f)));
  highlighted = [];
}

// Effacer filtre
clearFilterBtn.addEventListener('click', () => {
  attributeFilter.value = '';
  Array.from(attributesBody.rows).forEach(r => r.style.display = '');
  clearHighlight();
});

// Zoom sur feature
function zoomToFeature(idx) {
  const feature = layers[attrLayerSel.value].layer.getSource().getFeatures()[idx];
  const extent = feature.getGeometry().getExtent();
  map.getView().fit(extent, { duration: 500, padding: [100, 100, 100, 100] });
}

// Popup show
function showPopup(idx) {
  const feature = layers[attrLayerSel.value].layer.getSource().getFeatures()[idx];
  const coord = feature.getGeometry().getClosestPoint(map.getView().getCenter());
  const props = feature.getProperties();
  delete props.geometry;
  let html = '<table>';
  for (let key in props) {
    html += `<tr><th>${key}</th><td>${props[key]}</td></tr>`;
  }
  html += '</table>';
  popupContent.innerHTML = html;
  overlay.setPosition(coord);
}

// Clic sur la carte → popup
map.on('singleclick', evt => {
  clearHighlight();
  map.forEachFeatureAtPixel(evt.pixel, (feature, layer) => {
    const props = feature.getProperties();
    delete props.geometry;
    let info = '<table>';
    for (let key in props) info += `<tr><th>${key}</th><td>${props[key]}</td></tr>`;
    info += '</table>';
    popupContent.innerHTML = info;
    overlay.setPosition(evt.coordinate);
  });
});

// set attributs table
attrLayerSel.addEventListener('change', function() {
  const selectedLayer = this.value;
  const geojson = layers[selectedLayer].geojson; 
  setupAttributesTable(geojson);
});

// set attributeSLabel option
function setOptionForLabel(geojson) {
  attributeSLabel.innerHTML = '';

  const keys = Object.keys(geojson.features[0].properties);
  keys.forEach(k => {
    const opt = document.createElement('option'); opt.value = k; opt.text = k;
    attributeSLabel.appendChild(opt);
  });
}

styleLayerSel.addEventListener('change', function() {
  const selectedLayer = this.value;
  const geojson = layers[selectedLayer].geojson; 
  setOptionForLabel(geojson);
});

// Style dynamic
[fillColorInput, strokeColorInput, strokeWidthInput, fillOpacityInput, pointSymbolSel, attributeSLabel].forEach(c => c.onchange = applyStyle);
function applyStyle() {
  const idx   = +styleLayerSel.value;
  const { layer } = layers[idx];
  const field = attributeSLabel.value;

  layer.setStyle(feature => {
    // Récupération de la valeur
    const val = feature.get(field);
    const textString = val != null ? val.toString() : '';

    // Construction du style
    const styleOpts = {
      fill:   new ol.style.Fill({ color: hexToRgba(fillColorInput.value, fillOpacityInput.value) }),
      stroke: new ol.style.Stroke({ color: strokeColorInput.value, width: +strokeWidthInput.value }),
      text: new ol.style.Text({
        text:       textString,
        font:       '12px sans-serif',
        fill:       new ol.style.Fill({ color: '#000' }),
        stroke:     new ol.style.Stroke({ color: '#fff', width: 2 }),
        placement:  'point',
        offsetY:    -15
      })
    };

    // Optionnel : symbole de point
    if (pointSymbolSel.value) {
      styleOpts.image = new ol.style.Circle({
        radius: +pointSymbolSel.value, // ou un rayon fixe
        fill:   styleOpts.fill,
        stroke: styleOpts.stroke,
        text: new ol.style.Text({
          text:       textString,
          font:       '12px sans-serif',
          fill:       new ol.style.Fill({ color: '#000' }),
          stroke:     new ol.style.Stroke({ color: '#fff', width: 2 }),
          placement:  'point',
          offsetY:    -15
        })
      });
    }

    return new ol.style.Style(styleOpts);
  });
}

// Utilitaire
function hexToRgba(hex, a) {
  const [r,g,b] = hex.replace('#','').match(/.{2}/g).map(v => parseInt(v,16));
  return `rgba(${r},${g},${b},${a})`;
}


